Example of running the program:

python3 march_rooting_guide.py results.json Missouri Drake 1 christian.json david.json delilah.json

python3 [program name] [results file] [team 1] [team 2] [round that the game is played in] [pick JSONs]

There is a results.json that must be updated to current results

Include the two teams playing as team 1 and team 2. Make sure their names are the same as they are in the rest of the program

Follow the same system as the other pick JSON files